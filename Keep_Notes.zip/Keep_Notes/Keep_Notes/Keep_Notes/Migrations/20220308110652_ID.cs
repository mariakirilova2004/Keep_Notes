﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Keep_Notes.Migrations
{
    public partial class ID : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddPrimaryKey("Id", "notes", "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
