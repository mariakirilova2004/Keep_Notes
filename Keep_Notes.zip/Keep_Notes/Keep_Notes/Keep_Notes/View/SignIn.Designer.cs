﻿namespace Keep_Notes
{
    partial class signIn_Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.email_Label = new System.Windows.Forms.Label();
            this.keep_Notes_Label = new System.Windows.Forms.Label();
            this.email_TextBox = new System.Windows.Forms.TextBox();
            this.password_TextBox = new System.Windows.Forms.TextBox();
            this.password_Label = new System.Windows.Forms.Label();
            this.signIn_Button = new System.Windows.Forms.Button();
            this.register_LinkLabel = new System.Windows.Forms.LinkLabel();
            this.warning_Label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // email_Label
            // 
            this.email_Label.AutoSize = true;
            this.email_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.email_Label.Location = new System.Drawing.Point(112, 134);
            this.email_Label.Name = "email_Label";
            this.email_Label.Size = new System.Drawing.Size(76, 51);
            this.email_Label.TabIndex = 0;
            this.email_Label.Text = "Email:";
            // 
            // keep_Notes_Label
            // 
            this.keep_Notes_Label.AutoSize = true;
            this.keep_Notes_Label.BackColor = System.Drawing.Color.Transparent;
            this.keep_Notes_Label.Font = new System.Drawing.Font("Lucida Handwriting", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.keep_Notes_Label.ForeColor = System.Drawing.Color.MidnightBlue;
            this.keep_Notes_Label.Location = new System.Drawing.Point(158, 54);
            this.keep_Notes_Label.Name = "keep_Notes_Label";
            this.keep_Notes_Label.Size = new System.Drawing.Size(209, 43);
            this.keep_Notes_Label.TabIndex = 1;
            this.keep_Notes_Label.Text = "Keep Notes";
            // 
            // email_TextBox
            // 
            this.email_TextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.email_TextBox.Location = new System.Drawing.Point(194, 134);
            this.email_TextBox.Name = "email_TextBox";
            this.email_TextBox.Size = new System.Drawing.Size(245, 41);
            this.email_TextBox.TabIndex = 2;
            // 
            // password_TextBox
            // 
            this.password_TextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.password_TextBox.Location = new System.Drawing.Point(194, 198);
            this.password_TextBox.Name = "password_TextBox";
            this.password_TextBox.Size = new System.Drawing.Size(245, 41);
            this.password_TextBox.TabIndex = 4;
            // 
            // password_Label
            // 
            this.password_Label.AutoSize = true;
            this.password_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.password_Label.Location = new System.Drawing.Point(81, 198);
            this.password_Label.Name = "password_Label";
            this.password_Label.Size = new System.Drawing.Size(107, 51);
            this.password_Label.TabIndex = 3;
            this.password_Label.Text = "Password:";
            // 
            // signIn_Button
            // 
            this.signIn_Button.BackColor = System.Drawing.Color.Gainsboro;
            this.signIn_Button.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.signIn_Button.ForeColor = System.Drawing.Color.DarkBlue;
            this.signIn_Button.Location = new System.Drawing.Point(229, 309);
            this.signIn_Button.Name = "signIn_Button";
            this.signIn_Button.Size = new System.Drawing.Size(106, 53);
            this.signIn_Button.TabIndex = 5;
            this.signIn_Button.Text = "Sign in";
            this.signIn_Button.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.signIn_Button.UseVisualStyleBackColor = false;
            this.signIn_Button.Click += new System.EventHandler(this.signIn_Button_Click);
            // 
            // register_LinkLabel
            // 
            this.register_LinkLabel.AutoSize = true;
            this.register_LinkLabel.LinkColor = System.Drawing.Color.DarkBlue;
            this.register_LinkLabel.Location = new System.Drawing.Point(250, 386);
            this.register_LinkLabel.Name = "register_LinkLabel";
            this.register_LinkLabel.Size = new System.Drawing.Size(63, 20);
            this.register_LinkLabel.TabIndex = 6;
            this.register_LinkLabel.TabStop = true;
            this.register_LinkLabel.Text = "Register";
            this.register_LinkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.register_LinkLabel_LinkClicked);
            // 
            // warning_Label
            // 
            this.warning_Label.AutoSize = true;
            this.warning_Label.Font = new System.Drawing.Font("Gabriola", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.warning_Label.ForeColor = System.Drawing.Color.Firebrick;
            this.warning_Label.Location = new System.Drawing.Point(178, 256);
            this.warning_Label.Name = "warning_Label";
            this.warning_Label.Size = new System.Drawing.Size(0, 37);
            this.warning_Label.TabIndex = 7;
            // 
            // signIn_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(568, 450);
            this.Controls.Add(this.warning_Label);
            this.Controls.Add(this.register_LinkLabel);
            this.Controls.Add(this.signIn_Button);
            this.Controls.Add(this.password_TextBox);
            this.Controls.Add(this.password_Label);
            this.Controls.Add(this.email_TextBox);
            this.Controls.Add(this.keep_Notes_Label);
            this.Controls.Add(this.email_Label);
            this.Name = "signIn_Form";
            this.Text = "Sign In";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label email_Label;
        private System.Windows.Forms.Label keep_Notes_Label;
        private System.Windows.Forms.TextBox email_TextBox;
        private System.Windows.Forms.TextBox password_TextBox;
        private System.Windows.Forms.Label password_Label;
        private System.Windows.Forms.Button signIn_Button;
        private System.Windows.Forms.LinkLabel register_LinkLabel;
        private System.Windows.Forms.Label warning_Label;
    }
}
