﻿
namespace Keep_Notes.View
{
    partial class NoteEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleLabel = new System.Windows.Forms.Label();
            this.TitleTextBox = new System.Windows.Forms.TextBox();
            this.NoteTextLabel = new System.Windows.Forms.Label();
            this.NoteTextBox = new System.Windows.Forms.TextBox();
            this.PrivateComboBox = new System.Windows.Forms.ComboBox();
            this.LabelPrivate = new System.Windows.Forms.Label();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.CathegoryLabel = new System.Windows.Forms.Label();
            this.CategoryComboBox = new System.Windows.Forms.ComboBox();
            this.BackgroundLabel = new System.Windows.Forms.Label();
            this.BackgroundComboBox = new System.Windows.Forms.ComboBox();
            this.SaveButton = new System.Windows.Forms.Button();
            this.WarningLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TitleLabel.Location = new System.Drawing.Point(13, -1);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(60, 51);
            this.TitleLabel.TabIndex = 0;
            this.TitleLabel.Text = "Title";
            // 
            // TitleTextBox
            // 
            this.TitleTextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TitleTextBox.Location = new System.Drawing.Point(70, 9);
            this.TitleTextBox.Name = "TitleTextBox";
            this.TitleTextBox.Size = new System.Drawing.Size(158, 41);
            this.TitleTextBox.TabIndex = 1;
            this.TitleTextBox.TextChanged += new System.EventHandler(this.TitleTextBox_TextChanged);
            // 
            // NoteTextLabel
            // 
            this.NoteTextLabel.AutoSize = true;
            this.NoteTextLabel.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NoteTextLabel.Location = new System.Drawing.Point(13, 50);
            this.NoteTextLabel.Name = "NoteTextLabel";
            this.NoteTextLabel.Size = new System.Drawing.Size(102, 51);
            this.NoteTextLabel.TabIndex = 2;
            this.NoteTextLabel.Text = "Note text";
            // 
            // NoteTextBox
            // 
            this.NoteTextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NoteTextBox.Location = new System.Drawing.Point(13, 94);
            this.NoteTextBox.Multiline = true;
            this.NoteTextBox.Name = "NoteTextBox";
            this.NoteTextBox.Size = new System.Drawing.Size(341, 344);
            this.NoteTextBox.TabIndex = 3;
            this.NoteTextBox.TextChanged += new System.EventHandler(this.NoteTextBox_TextChanged);
            // 
            // PrivateComboBox
            // 
            this.PrivateComboBox.DisplayMember = "str";
            this.PrivateComboBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PrivateComboBox.FormattingEnabled = true;
            this.PrivateComboBox.Location = new System.Drawing.Point(516, 33);
            this.PrivateComboBox.Name = "PrivateComboBox";
            this.PrivateComboBox.Size = new System.Drawing.Size(151, 45);
            this.PrivateComboBox.TabIndex = 4;
            this.PrivateComboBox.ValueMember = "val";
            this.PrivateComboBox.SelectedIndexChanged += new System.EventHandler(this.PrivateComboBox_SelectedIndexChanged);
            // 
            // LabelPrivate
            // 
            this.LabelPrivate.AutoSize = true;
            this.LabelPrivate.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LabelPrivate.Location = new System.Drawing.Point(392, 27);
            this.LabelPrivate.Name = "LabelPrivate";
            this.LabelPrivate.Size = new System.Drawing.Size(82, 51);
            this.LabelPrivate.TabIndex = 5;
            this.LabelPrivate.Text = "Private";
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordLabel.Location = new System.Drawing.Point(392, 78);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(102, 51);
            this.PasswordLabel.TabIndex = 6;
            this.PasswordLabel.Text = "Password";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordTextBox.Location = new System.Drawing.Point(516, 84);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(151, 41);
            this.PasswordTextBox.TabIndex = 7;
            this.PasswordTextBox.TextChanged += new System.EventHandler(this.PasswordTextBox_TextChanged);
            // 
            // CathegoryLabel
            // 
            this.CathegoryLabel.AutoSize = true;
            this.CathegoryLabel.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CathegoryLabel.Location = new System.Drawing.Point(392, 128);
            this.CathegoryLabel.Name = "CathegoryLabel";
            this.CathegoryLabel.Size = new System.Drawing.Size(100, 51);
            this.CathegoryLabel.TabIndex = 8;
            this.CathegoryLabel.Text = "Category";
            // 
            // CategoryComboBox
            // 
            this.CategoryComboBox.DisplayMember = "str";
            this.CategoryComboBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CategoryComboBox.FormattingEnabled = true;
            this.CategoryComboBox.Location = new System.Drawing.Point(516, 134);
            this.CategoryComboBox.Name = "CategoryComboBox";
            this.CategoryComboBox.Size = new System.Drawing.Size(151, 45);
            this.CategoryComboBox.TabIndex = 9;
            this.CategoryComboBox.ValueMember = "val";
            this.CategoryComboBox.SelectedIndexChanged += new System.EventHandler(this.CategoryComboBox_SelectedIndexChanged);
            // 
            // BackgroundLabel
            // 
            this.BackgroundLabel.AutoSize = true;
            this.BackgroundLabel.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackgroundLabel.Location = new System.Drawing.Point(392, 182);
            this.BackgroundLabel.Name = "BackgroundLabel";
            this.BackgroundLabel.Size = new System.Drawing.Size(129, 51);
            this.BackgroundLabel.TabIndex = 10;
            this.BackgroundLabel.Text = "Background";
            // 
            // BackgroundComboBox
            // 
            this.BackgroundComboBox.DisplayMember = "str";
            this.BackgroundComboBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.BackgroundComboBox.FormattingEnabled = true;
            this.BackgroundComboBox.Location = new System.Drawing.Point(516, 187);
            this.BackgroundComboBox.Name = "BackgroundComboBox";
            this.BackgroundComboBox.Size = new System.Drawing.Size(151, 45);
            this.BackgroundComboBox.TabIndex = 11;
            this.BackgroundComboBox.ValueMember = "val";
            this.BackgroundComboBox.SelectedIndexChanged += new System.EventHandler(this.BackgroundComboBox_SelectedIndexChanged);
            // 
            // SaveButton
            // 
            this.SaveButton.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SaveButton.Location = new System.Drawing.Point(492, 341);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(101, 61);
            this.SaveButton.TabIndex = 12;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // WarningLabel
            // 
            this.WarningLabel.AutoSize = true;
            this.WarningLabel.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WarningLabel.Location = new System.Drawing.Point(360, 233);
            this.WarningLabel.Name = "WarningLabel";
            this.WarningLabel.Size = new System.Drawing.Size(0, 51);
            this.WarningLabel.TabIndex = 13;
            // 
            // NoteEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(701, 450);
            this.Controls.Add(this.WarningLabel);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.BackgroundComboBox);
            this.Controls.Add(this.BackgroundLabel);
            this.Controls.Add(this.CategoryComboBox);
            this.Controls.Add(this.CathegoryLabel);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.PasswordLabel);
            this.Controls.Add(this.LabelPrivate);
            this.Controls.Add(this.PrivateComboBox);
            this.Controls.Add(this.NoteTextBox);
            this.Controls.Add(this.NoteTextLabel);
            this.Controls.Add(this.TitleTextBox);
            this.Controls.Add(this.TitleLabel);
            this.ForeColor = System.Drawing.Color.DarkBlue;
            this.Name = "NoteEditor";
            this.Text = "NoteEditor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NoteEditor_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.TextBox TitleTextBox;
        private System.Windows.Forms.Label NoteTextLabel;
        private System.Windows.Forms.TextBox NoteTextBox;
        private System.Windows.Forms.ComboBox PrivateComboBox;
        private System.Windows.Forms.Label LabelPrivate;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label CathegoryLabel;
        private System.Windows.Forms.ComboBox CategoryComboBox;
        private System.Windows.Forms.Label BackgroundLabel;
        private System.Windows.Forms.ComboBox BackgroundComboBox;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Label WarningLabel;
    }
}