﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Keep_Notes
{
    public partial class Ready : Form
    {
        // Declared the business logic for the Ready_Form
        static Logic_Ready_Form logic_Ready_Form;
        public Register register;
        public Ready(Register register, string[] strings)
        {
            InitializeComponent();
            logic_Ready_Form = new Logic_Ready_Form(strings);
            this.register = register;
        }

        private void Ready_Load(object sender, EventArgs e)
        {
            //Setting the public variables from the register form here
            emailOutput_Label.Text = logic_Ready_Form.stringsForLabels[3];
            passwordOutput_Label.Text = logic_Ready_Form.stringsForLabels[4];
            cityOutput_Label.Text = logic_Ready_Form.stringsForLabels[5];
            ageOutput_Label.Text = logic_Ready_Form.stringsForLabels[6];
        }

        private void ready_Button_Click(object sender, EventArgs e)
        {
            logic_Ready_Form.On_Ready_Button_Click(this);
            register.signIn_Form.Show();
            register.Close();
            this.Close();
        }

        private void edit_Button_Click(object sender, EventArgs e)
        {
            //If the costumer is not ready with the registration this form should be closed and the registration form shold stay active
            this.Close();
            

        }

        private void Ready_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (register.IsDisposed == false)
                register.Show();
                
           
        }
    }
}
