﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Keep_Notes
{
    public partial class signIn_Form : Form
    {
        // Declared the business logic for the Sign_In_Form
        static Logic_SignIn_Form logic_SignIn_Form = new Logic_SignIn_Form();

        Users theUser;

        NotesMenu notesMenu;
        public signIn_Form()
        {
            InitializeComponent();
            
        }

        private void signIn_Button_Click(object sender, EventArgs e)
        {
            //set textboxes as paramether to reset them if needed
            Tuple<string, Users> ans = logic_SignIn_Form.OnSignInButtonClick(email_TextBox.Text, password_TextBox.Text);

            //Checking if the user exists in the database 
            if (ans.Item1 == "READY")
            {
                // theUser should be used for the notes
                theUser = (Users)ans.Item2;

                notesMenu = new NotesMenu(theUser, this);
                notesMenu.Show();
                this.Hide();//closing this window would end the application so we hide it
                                   //reset text fields
                email_TextBox.Text = "";
                password_TextBox.Text = "";
                warning_Label.Text = "";
            }
            else
            {
                warning_Label.Text = ans.Item1;
            }
        }
        private void register_LinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
          
                // The transition between the Sign_In_Form and the Register_Form
                var registerForm = new Register(this);
                registerForm.Show();
                this.Hide();
           
        }
    }
}
