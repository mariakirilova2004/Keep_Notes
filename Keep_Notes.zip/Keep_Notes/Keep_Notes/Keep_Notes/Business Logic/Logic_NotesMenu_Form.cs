﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
namespace Keep_Notes.Business_Logic
{
   public class Logic_NotesMenu_Form
    {
        public static  KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
       public KeepNotesDBContext context
        {
            set { keepNotesDBContext = value; }
            get { return keepNotesDBContext; }
        }
        public Logic_NotesMenu_Form(KeepNotesDBContext context=null)
        {
            if(context!=null)
            {
                keepNotesDBContext = context;
            }
        }
        //Updating the components of the updated note
        public List<string> UpdateNoteList(int UserId,string keyword="Any")
        {
           
            List<Notes> listOfNotes;
            if(keyword == "Any")
            listOfNotes = keepNotesDBContext.Notes.Where(n => n.UserId == UserId).OrderByDescending(n => n.latest_change).ToList();
            else
                listOfNotes = keepNotesDBContext.Notes.Where(n => n.UserId == UserId && n.Keywords == keyword).OrderByDescending(n => n.latest_change).ToList();

            List<string> titles = new List<string>(listOfNotes.Count);
            foreach (var i in listOfNotes)
                titles.Add(i.Title);
           
            return titles;
        }

        // Displaying the note
        public string DisplayNotePreview(string title,int user_id,bool locked)
        {
            if (locked)
                    if (keepNotesDBContext.Notes.Where(n => n.Title.Equals(title,StringComparison.Ordinal) && n.UserId == user_id).FirstOrDefault().Private)
                        return "***********";
                              
                    var note = keepNotesDBContext.Notes.Where(n => n.Title.Equals(title,StringComparison.Ordinal) && n.UserId == user_id).FirstOrDefault();
                    StringBuilder prevText = new StringBuilder();

                    foreach (var i in note.Note.Take(20))
                    {
                        prevText.Append(i);

                    }

                    return prevText + (note.Note.Length > 20 ? "..." : "");            
            
        }
        public System.Drawing.Color DisplayNoteColor(string title,int user_id)
        {
            string color = keepNotesDBContext.Notes.Where(n => n.Title.Equals(title,StringComparison.Ordinal) && n.UserId == user_id).FirstOrDefault().Color.ToString();
            switch (color)
            {               
                case "Green": return System.Drawing.Color.LimeGreen;
                case "Blue":   return System.Drawing.Color.Blue;
                default: return System.Drawing.Color.White;
            } 
        }

        public void DeleteNode(string title,int user_id)
        {
            var ToRemove = keepNotesDBContext.Notes.Where(n => n.Title.Equals(title,StringComparison.Ordinal) && n.UserId == user_id).FirstOrDefault();
            keepNotesDBContext.Notes.Remove(ToRemove);

            keepNotesDBContext.SaveChanges();
        }

        //Checking if the note is private
        public bool isPrivate(string title,int user_id)
        {
            return keepNotesDBContext.Notes.Where(n => n.Title.Equals(title,StringComparison.Ordinal) && n.UserId == user_id).FirstOrDefault().Private;
        }

        //Checking if password is correct
        public bool PasswordIsCorrect(string title,int user_id,string password)
        {
            string Hash;
            using (var sha256 = SHA256.Create())
            {
                // Send a sample text to hash.  
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                // Get the hashed string.  
                var hash = BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
                Hash = hash;
            };
            return keepNotesDBContext.Notes.Where(n => n.Title.Equals(title,StringComparison.Ordinal) && n.UserId == user_id).FirstOrDefault().Password == Hash;  
        }

        //Getting the ID of the note 
        public int getId(string title,int user_id)
        {
             return keepNotesDBContext.Notes.Where(n => n.Title.Equals(title,StringComparison.Ordinal) && n.UserId == user_id).FirstOrDefault().Id; 
        }
    }
}
