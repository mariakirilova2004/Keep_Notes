﻿using System;
using System.Collections.Generic;
using System.Text;
using Keep_Notes.Model;
using Keep_Notes.Business_Logic;
using NUnit.Framework;
using System.Linq;

namespace Keep_Notes.Test
{
    [TestFixture]
    class Logic_NotesMenu_FormTest
    {
        private KeepNotesDBContext keepNotesDBContext;
        [SetUp]
        public void SetUp()
        {
            keepNotesDBContext = new KeepNotesDBContext();
            keepNotesDBContext.Database.BeginTransaction();
          
          
        }

        [TearDown]
        public void TearDown()
        {
            keepNotesDBContext.Database.RollbackTransaction();
        }

        
        [Test]
        
        public void DisplayNotePreview_NoteIsDisplayed()
        {
           
            //Arrange
            Logic_NotesMenu_Form logic = new Logic_NotesMenu_Form(keepNotesDBContext);
            logic.context = keepNotesDBContext;
            logic.context = keepNotesDBContext;
            Cities city = new Cities();
            if (keepNotesDBContext.Cities.ToList().Count == 0)
                city.Id = 1;
            else
                city.Id = keepNotesDBContext.Cities.Max(n => n.Id) + 1;
            city.Name = "Test";
            Users user = new Users();
            if (keepNotesDBContext.Users.ToList().Count == 0)
                user.Id = 1;
            else
                user.Id = keepNotesDBContext.Users.Max(n => n.Id) + 1;
            user.Username = "Test";
            user.Password = "Test";
            user.CityId = city.Id;
            user.AgeGroupId = 1;


            Notes note = new Notes();
            if (keepNotesDBContext.Notes.ToList().Count == 0)
                note.Id = 1;
            else
                note.Id = keepNotesDBContext.Notes.Max(n => n.Id) + 1;
            note.Title = "Test";
            note.Note = "Test";
            note.UserId = user.Id;
            note.Private = true;
            Notes note2 = new Notes();
            if (keepNotesDBContext.Notes.ToList().Count == 0)
                note2.Id = 2;
            else
                note2.Id = keepNotesDBContext.Notes.Max(n => n.Id) + 2;
            note2.Title = "TestTest";
            note2.Note = "TestTestTestTestTestTest";
            note2.UserId = user.Id;
            note2.Private = false;
            note2.Keywords = "Cooking";
            keepNotesDBContext.Cities.Add(city);
            keepNotesDBContext.Users.Add(user);
            keepNotesDBContext.Notes.Add(note);
            keepNotesDBContext.Notes.Add(note2);
            keepNotesDBContext.SaveChanges();
            //Act
            string NoteReturnedUnlocked = logic.DisplayNotePreview("Test",keepNotesDBContext.Notes.OrderByDescending(n=>n.Id).Skip(1).First().UserId,false);
            string NoteReturnedLocked = logic.DisplayNotePreview("Test", keepNotesDBContext.Notes.OrderByDescending(n => n.Id).Skip(1).First().UserId, true);
            string NoteReturnedUnlocked2 = logic.DisplayNotePreview("TestTest", keepNotesDBContext.Notes.OrderByDescending(n => n.Id).First().UserId, false);
            string NoteReturnedLocked2 = logic.DisplayNotePreview("TestTest", keepNotesDBContext.Notes.OrderByDescending(n => n.Id).First().UserId, true);

            //Assert
            Assert.AreEqual("Test", NoteReturnedUnlocked, "Note wasn't displayed properly");
            Assert.AreEqual("***********", NoteReturnedLocked, "Note locking is not working properly");
            Assert.AreEqual("TestTestTestTestTest...", NoteReturnedUnlocked2, "Note wasn't displayed properly");
            Assert.AreEqual("TestTestTestTestTest...", NoteReturnedLocked2, "Note locking is not working properly");
        }
        [Test]
        public void UpdateNoteList_TitlesAreReturned()
        {
            //Arrange
            Logic_NotesMenu_Form logic = new Logic_NotesMenu_Form(keepNotesDBContext);
            logic.context = keepNotesDBContext;
            Cities city = new Cities();
            if (keepNotesDBContext.Cities.ToList().Count == 0)
                city.Id = 1;
            else
                city.Id = keepNotesDBContext.Cities.Max(n => n.Id) + 1;
            city.Name = "Test";
            Users user = new Users();
            if (keepNotesDBContext.Users.ToList().Count == 0)
                user.Id = 1;
            else
                user.Id = keepNotesDBContext.Users.Max(n => n.Id) + 1;
            user.Username = "Test";
            user.Password = "Test";
            user.CityId = city.Id;
            user.AgeGroupId = 1;


            Notes note = new Notes();
            if (keepNotesDBContext.Notes.ToList().Count == 0)
                note.Id = 1;
            else
                note.Id = keepNotesDBContext.Notes.Max(n => n.Id) + 1;
            note.Title = "Test";
            note.Note = "Test";
            note.UserId = user.Id;
            note.Private = true;
            Notes note2 = new Notes();
            if (keepNotesDBContext.Notes.ToList().Count == 0)
                note2.Id = 2;
            else
                note2.Id = keepNotesDBContext.Notes.Max(n => n.Id) + 2;
            note2.Title = "TestTest";
            note2.Note = "TestTestTestTestTestTest";
            note2.UserId = user.Id;
            note2.Private = false;
            note2.Keywords = "Cooking";
            keepNotesDBContext.Cities.Add(city);
            keepNotesDBContext.Users.Add(user);
            keepNotesDBContext.Notes.Add(note);
            keepNotesDBContext.Notes.Add(note2);
            keepNotesDBContext.SaveChanges();
            //Act
            var titles1 = logic.UpdateNoteList(user.Id);
            var titles2 = logic.UpdateNoteList(user.Id,"Cooking");

            //Assert
            Assert.AreEqual( new List<string>{ "Test","TestTest"},titles1,"Incorrect titles returned");
            Assert.AreEqual(new List<string> { "TestTest" }, titles2, "Incorrect titles returned by cathegory");
        }
        [Test]
        public void DeleteNote_NoteDeleted()
        {
            //Arrange
            Logic_NotesMenu_Form logic = new Logic_NotesMenu_Form(keepNotesDBContext);

            Cities city = new Cities();
            if (keepNotesDBContext.Cities.ToList().Count == 0)
                city.Id = 1;
            else
                city.Id = keepNotesDBContext.Cities.Max(n => n.Id) + 1;
            city.Name = "Test";
            Users user = new Users();
            if (keepNotesDBContext.Users.ToList().Count == 0)
                user.Id = 1;
            else
                user.Id = keepNotesDBContext.Users.Max(n => n.Id) + 1;
            user.Username = "Test";
            user.Password = "Test";
            user.CityId = city.Id;
            user.AgeGroupId = 1;


            Notes note = new Notes();
            if (keepNotesDBContext.Notes.ToList().Count == 0)
                note.Id = 1;
            else
                note.Id = keepNotesDBContext.Notes.Max(n => n.Id) + 1;
            note.Title = "Test";
            note.Note = "Test";
            note.UserId = user.Id;
            note.Private = true;
            keepNotesDBContext.Cities.Add(city);
            keepNotesDBContext.Users.Add(user);
            keepNotesDBContext.Notes.Add(note);
          
            keepNotesDBContext.SaveChanges();
            //Act
            logic.DeleteNode(note.Title, note.UserId);
            note = keepNotesDBContext.Notes.Where(n => n.Title.Equals(note.Title)&& n.Id==note.Id).FirstOrDefault();

            //Assert

            Assert.IsNull(note, "Note wasn't deleted");
        }
       
    }
}
