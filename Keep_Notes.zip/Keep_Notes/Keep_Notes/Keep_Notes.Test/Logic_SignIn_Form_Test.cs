﻿using System;
using System.Collections.Generic;
using System.Text;
using Keep_Notes.Model;
using Keep_Notes.Business_Logic;
using NUnit.Framework;
using System.Linq;
using System.Security.Cryptography;

namespace Keep_Notes.Test
{
    [TestFixture]
    class Logic_SignIn_Form_Test
    {
        KeepNotesDBContext keepNotesDBContext;
        [SetUp]
        public void SetUp()
        {
            keepNotesDBContext = new KeepNotesDBContext();
            keepNotesDBContext.Database.BeginTransaction();
        }

        [TearDown]
        public void TearDown()
        {
            keepNotesDBContext.Database.RollbackTransaction();
        }

        [Test]
        public void OnSignInButtonClick()
        {
            //Arrange
            Logic_SignIn_Form signInForm_Logic = new Logic_SignIn_Form();
            Cities city = new Cities();
            if (keepNotesDBContext.Cities.ToList().Count == 0) city.Id = 1;
            else city.Id = keepNotesDBContext.Cities.Max(n => n.Id) + 1;
            city.Name = "Test";
            Users user = new Users();
            if (keepNotesDBContext.Users.ToList().Count == 0) user.Id = 1;
            else user.Id = keepNotesDBContext.Users.Max(n => n.Id) + 1;
            user.Username = "Test@test.com";
            user.Password = "Tests";
            user.CityId = city.Id;
            user.AgeGroupId = 1;
            keepNotesDBContext.Cities.Add(city);
            keepNotesDBContext.Users.Add(user);
            keepNotesDBContext.SaveChanges();
            //Act
            Tuple<string, Users> ans = signInForm_Logic.OnSignInButtonClick(user.Username, "Test");
            //Assert
            Tuple<string, Users> equal = new Tuple<string, Users>("Wrong password or email", null);
            Assert.AreEqual(ans, equal);

        }

    }
}
