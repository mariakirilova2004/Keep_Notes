﻿using System;
using System.Collections.Generic;
using System.Text;
using Keep_Notes.Model;
using Keep_Notes.Business_Logic;
using NUnit.Framework;
using System.Linq;
using System.Security.Cryptography;

namespace Keep_Notes.Test
{
    [TestFixture]
    class Logic_Register_Form_Test
    {
        KeepNotesDBContext keepNotesDBContext;
        [SetUp]
        public void SetUp()
        {
            keepNotesDBContext = new KeepNotesDBContext();
            keepNotesDBContext.Database.BeginTransaction();
        }

        [TearDown]
        public void TearDown()
        {
            keepNotesDBContext.Database.RollbackTransaction();
        }

        [Test]
        public void On_Ready_Button_Click()
        {
            //Arrange
            Logic_Register_Form registerForm_Logic = new Logic_Register_Form();
            //Act
            string[] ans1 = registerForm_Logic.On_Ready_Button_Click("Koko", "", "", "", ""); ;
            string[] ans2 = registerForm_Logic.On_Ready_Button_Click("Proba@proba.com", "12", "", "", ""); 
            string[] ans3 = registerForm_Logic.On_Ready_Button_Click("Proba@proba.com", "12345", "123456", "", "");
            string[] ans4 = registerForm_Logic.On_Ready_Button_Click("Proba@proba.com", "12345", "12345", "Rus", "");
            string[] ans5 = registerForm_Logic.On_Ready_Button_Click("Proba@proba.com", "12345", "12345", "Ruse", "");
            string[] ans6 = registerForm_Logic.On_Ready_Button_Click("Proba@proba.com", "12345", "12345", "Ruse", "6");
            string[] ans7 = registerForm_Logic.On_Ready_Button_Click("Proba@proba.com", "12345", "12345", "Ruse", "8");
            //Assert
            string[] equal1 = new string[] { "Wrong email. Enter a valid one!", "" };
            string[] equal2 = new string[] { "", "The password must be at least 5 symbols!" };
            string[] equal3 = new string[] { "", "The second password must be identical to the first one!" };
            string[] equal4 = new string[] { "Enter a valid city name", "" };
            string[] equal5 = new string[] { "Enter an age!", "" };
            string[] equal6 = new string[] { "", "You cannot make a registration if you are not at least 7 year old!" };
            string id = "";
            if (keepNotesDBContext.Users.ToList().Count == 0) id = "1";
            else id = (keepNotesDBContext.Users.OrderByDescending(p => p.Id).FirstOrDefault().Id + 1).ToString();
            string[] equal7 = new string[] { "READY", "", id, "Proba@proba.com", "12345" , "Ruse", "8" };
            Assert.AreEqual(ans1, equal1);
            Assert.AreEqual(ans2, equal2);
            Assert.AreEqual(ans3, equal3);
            Assert.AreEqual(ans4, equal4);
            Assert.AreEqual(ans5, equal5);
            Assert.AreEqual(ans6, equal6);
            Assert.AreEqual(ans7, equal7);
        }

    }
}