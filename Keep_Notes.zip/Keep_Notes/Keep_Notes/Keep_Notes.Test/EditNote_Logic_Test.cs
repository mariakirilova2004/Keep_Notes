﻿using System;
using System.Collections.Generic;
using System.Text;
using Keep_Notes.Model;
using Keep_Notes.Business_Logic;
using NUnit.Framework;
using System.Linq;

namespace Keep_Notes.Test
{
    [TestFixture]
    class EditNote_Logic_Test
    {
        KeepNotesDBContext keepNotesDBContext;
        EditNote_Logic logic;
        [SetUp]
        public void SetUp()
        {
            keepNotesDBContext = new KeepNotesDBContext();
            logic = new EditNote_Logic(keepNotesDBContext);
            keepNotesDBContext.Database.BeginTransaction();


        }

        [TearDown]
        public void TearDown()
        {
            keepNotesDBContext.Database.RollbackTransaction();
        }

        [Test]
        public void Save_NoteSaved()
        {
            Cities city = new Cities();
            if (keepNotesDBContext.Cities.ToList().Count == 0)
                city.Id = 1;
            else
                city.Id = keepNotesDBContext.Cities.Max(n => n.Id) + 1;
            city.Name = "Test";
            Users user = new Users();
            if (keepNotesDBContext.Users.ToList().Count == 0)
                user.Id = 1;
            else
                user.Id = keepNotesDBContext.Users.Max(n => n.Id) + 1;
            user.Username = "Test";
            user.Password = "Test";
            user.CityId = city.Id;
            user.AgeGroupId = 1;

            keepNotesDBContext.Cities.Add(city);
            keepNotesDBContext.Users.Add(user);
            keepNotesDBContext.SaveChanges();
            //Arrange
            NewNote_Logic newNote_Logic = new NewNote_Logic(keepNotesDBContext);

            newNote_Logic.Save(user.Id, "Test", "TEST TEST TEST", false, "Other", "Green", "",
                keepNotesDBContext.Notes.ToList().Count == 0 ? 0 : keepNotesDBContext.Notes.Max(n => n.Id) + 1);
            newNote_Logic.Save(keepNotesDBContext.Notes.Max(n => n.UserId), "test", "TEST TEST TEST", false, "Other", "Green", "", keepNotesDBContext.Notes.Max(n => n.Id) + 1);
            //Act
            string ans = logic.Save(keepNotesDBContext.Notes.Max(n => n.UserId), "TesT", "TEST TEST", false, "Other", "Green", "", keepNotesDBContext.Notes.Max(n => n.Id));
            string ans2 = logic.Save(keepNotesDBContext.Notes.Max(n => n.UserId), "TesT", "TEST TEST", false, "Other", "Green", "", keepNotesDBContext.Notes.Max(n => n.Id) - 1);
            Assert.AreEqual(ans, "Note Saved", "Note not saved");
            Assert.AreEqual(ans2, "Invalid title", "Title differentiation not working");


        }

    }
}
