﻿using System;
using System.Collections.Generic;
using System.Text;
using Keep_Notes.Model;
using Keep_Notes.Business_Logic;
using NUnit.Framework;
using System.Linq;
namespace Keep_Notes.Test
{[TestFixture]
    class NewNote_Logic_Test
    {
        KeepNotesDBContext keepNotesDBContext;
        NewNote_Logic logic;
        [SetUp]
        public void SetUp()
        {
            keepNotesDBContext = new KeepNotesDBContext();
            logic = new NewNote_Logic(keepNotesDBContext);
            keepNotesDBContext.Database.BeginTransaction();
          
        }

        [TearDown]
        public void TearDown()
        {
            keepNotesDBContext.Database.RollbackTransaction();
        }

        [Test]
        public void Save_NoteSaved()
        {
            //Arrange
            //making sure databases arent empty
            Cities city = new Cities();
            if (keepNotesDBContext.Cities.ToList().Count == 0)
                city.Id = 1;
            else
                city.Id = keepNotesDBContext.Cities.Max(n => n.Id) + 1;
            city.Name = "Test";
            Users user = new Users();
            if (keepNotesDBContext.Users.ToList().Count == 0)
                user.Id = 1;
            else
                user.Id = keepNotesDBContext.Users.Max(n => n.Id) + 1;
            user.Username = "Test";
            user.Password = "Test";
            user.CityId = city.Id;
            user.AgeGroupId = 1;

          
            Notes note = new Notes();
            if (keepNotesDBContext.Notes.ToList().Count == 0)
                note.Id = 1;
            else
                note.Id = keepNotesDBContext.Notes.Max(n => n.Id) + 1;
            note.Title = "Test";
            note.Note = "Test";
            note.UserId = user.Id;
            note.Private = true;
            keepNotesDBContext.Cities.Add(city);
            keepNotesDBContext.Users.Add(user);
            keepNotesDBContext.Notes.Add(note);
            keepNotesDBContext.SaveChanges();
            //Act
            string ans = logic.Save(keepNotesDBContext.Notes.Max(n => n.UserId), "TesT", "TEST TEST", false, "Other", "Green");
            string ans2 = logic.Save(keepNotesDBContext.Notes.Max(n => n.UserId), "TesT", "TEST TEST", false, "Other", "Green");
            Assert.AreEqual(ans, "Note Saved", "Note not saved");
            Assert.AreEqual(ans2, "Invalid title", "Title differentiation not working");


        }
    }
}
